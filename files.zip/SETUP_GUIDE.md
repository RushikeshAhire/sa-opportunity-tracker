# SA Opportunity Tracker — Cloud Database Setup Guide

This version replaces browser Local Storage with **Firebase Firestore**
(Google's free-tier cloud database). Once configured, every SA who opens
the page — on any laptop, any browser — reads and writes to the **same
shared database**. Admin sees adds/edits/deletes from everyone, live,
with no manual export/import.

Cost: **₹0**. Firebase's free "Spark" plan covers this app's usage
comfortably (limits are ~50K reads and ~20K writes per day — far more
than a small team needs).

---

## Step 1 — Create a free Firebase project (5 minutes)

1. Go to https://console.firebase.google.com and sign in with any Google account.
2. Click **Add project** → give it a name, e.g. `sa-opportunity-tracker`.
3. Disable Google Analytics for this project (not needed) → **Create project**.

## Step 2 — Create the Firestore database

1. In the left sidebar, go to **Build → Firestore Database**.
2. Click **Create database**.
3. Choose a location close to India, e.g. `asia-south1 (Mumbai)`.
4. Start in **Test mode** for now (open read/write). This is fine for an
   internal team tool behind a not-publicly-advertised URL. If you later
   want tighter control, see the "Security" note at the bottom.

## Step 3 — Register a Web App and get your config keys

1. In the Firebase console, click the **gear icon → Project settings**.
2. Under "Your apps", click the **</> (Web)** icon to register a new web app.
3. Give it any nickname (e.g. `tracker-web`) → **Register app**.
4. Firebase will show a `firebaseConfig` object like this:

   ```js
   const firebaseConfig = {
     apiKey: "AIza...",
     authDomain: "sa-opportunity-tracker.firebaseapp.com",
     projectId: "sa-opportunity-tracker",
     storageBucket: "sa-opportunity-tracker.appspot.com",
     messagingSenderId: "123456789",
     appId: "1:123456789:web:abcdef123456"
   };
   ```

5. Copy these values.

## Step 4 — Paste your keys into the HTML file

Open `SA_Opportunity_Tracker_Cloud.html`, find this block near the top of
the `<script>` section, and replace the placeholder values with the ones
from Step 3:

```js
const firebaseConfig={
 apiKey:"YOUR_API_KEY",
 authDomain:"YOUR_PROJECT_ID.firebaseapp.com",
 projectId:"YOUR_PROJECT_ID",
 storageBucket:"YOUR_PROJECT_ID.appspot.com",
 messagingSenderId:"YOUR_SENDER_ID",
 appId:"YOUR_APP_ID"
};
```

Save the file.

> Note: these keys are meant to be public — Firebase's web SDK is
> designed to ship them inside client-side code. Access control is
> handled by Firestore **Security Rules**, not by hiding these values.

## Step 5 — Host on GitHub Pages

1. Create a GitHub repo (e.g. `sa-opportunity-tracker`), public or private.
2. Upload `SA_Opportunity_Tracker_Cloud.html` and rename it to `index.html`
   (or keep its name and open it directly by filename).
3. Go to **Settings → Pages** in the repo → set Source to your main
   branch, root folder → Save.
4. GitHub gives you a URL like
   `https://<your-username>.github.io/sa-opportunity-tracker/`.
5. Share that single URL with your whole SA team. Everyone logs in with
   the same USERS list already in the file and now shares one live
   database.

## Step 6 — Test it

- Open the URL in two different browsers (or a normal + incognito window).
- Log in as two different SAs.
- Add an opportunity in one → it should appear instantly (a few seconds)
  in the Admin's "All Opportunities" and "Dashboard" views in the other
  window, without refreshing.

---

## Optional — Tighten security later

Test mode leaves the database open to anyone with the URL/keys. Once
you're ready, go to **Firestore Database → Rules** and replace the test
rule with something scoped to your app, e.g. requiring a simple shared
secret, or migrating logins to real **Firebase Authentication** (email/
password) and writing rules like:

```
match /opportunities/{doc} {
  allow read, write: if request.auth != null;
}
```

That's a bigger change (real login instead of the current hardcoded
password list) — happy to build that out too if/when you want it.
